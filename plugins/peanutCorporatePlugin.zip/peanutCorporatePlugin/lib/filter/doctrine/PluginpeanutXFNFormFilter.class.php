<?php

/**
 * PluginpeanutXFN form.
 *
 * @package    peanutCorporatePlugin
 * @subpackage filter
 * @author     Alexandre "pocky" Balmes <albalmes@gmail.com> <albalmes@gmail.com>
 * @version    SVN: $Id: sfDoctrineFormFilterPluginTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
abstract class PluginpeanutXFNFormFilter extends BasepeanutXFNFormFilter
{
  public function setup()
  {
  }
}
