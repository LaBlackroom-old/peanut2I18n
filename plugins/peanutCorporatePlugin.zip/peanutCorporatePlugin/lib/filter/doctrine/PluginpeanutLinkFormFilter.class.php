<?php

/**
 * peanutLink filter form base class.
 *
 * @package    peanutCorporatePlugin
 * @subpackage filter
 * @author     Alexandre "pocky" Balmes <albalmes@gmail.com> <albalmes@gmail.com>
 * @version    SVN: $Id: sfDoctrineFormFilterGeneratedInheritanceTemplate.php 29570 2010-05-21 14:49:47Z Kris.Wallsmith $
 */
abstract class PluginpeanutLinkFormFilter extends BasepeanutLinkFormFilter
{
  public function setup()
  {
    parent::setup();
  }
}
