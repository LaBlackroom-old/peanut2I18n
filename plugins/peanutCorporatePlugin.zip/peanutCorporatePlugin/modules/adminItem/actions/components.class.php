<?php

/**
 * adminItem components.
 *
 * @package    peanutCorporatePlugin
 * @subpackage adminItem
 * @author     Alexandre "pocky" Balmes <albalmes@gmail.com>
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class adminItemComponents extends sfComponents
{
  public function executeMenu()
  {
  }
}
