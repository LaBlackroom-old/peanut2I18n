<li class="sf_admin_action_create new page">
  <?php echo link_to(__('Create new page', array(), 'messages'), 'adminPage/new', array()) ?>
</li>
<li class="sf_admin_action_create new link">
  <?php echo link_to(__('Create new link', array(), 'messages'), 'adminLink/new', array()) ?>
</li>