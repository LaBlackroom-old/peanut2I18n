<td>
  <input type="checkbox" name="ids[]" value="<?php echo $peanut_menu->getPrimaryKey() ?>" class="sf_admin_batch_checkbox" />
  <input type="hidden" id="select_node-<?php echo $peanut_menu->getPrimaryKey() ?>" name="newparent[<?php echo $peanut_menu->getPrimaryKey() ?>]" />
</td>
