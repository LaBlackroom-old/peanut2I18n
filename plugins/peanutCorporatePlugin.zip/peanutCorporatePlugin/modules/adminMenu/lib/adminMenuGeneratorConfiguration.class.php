<?php

/**
 * adminMenu module configuration.
 *
 * @package    peanutCorporatePlugin
 * @subpackage adminMenu
 * @author     Alexandre "pocky" Balmes <albalmes@gmail.com>
 * @version    SVN: $Id: configuration.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class adminMenuGeneratorConfiguration extends BaseAdminMenuGeneratorConfiguration
{
}
