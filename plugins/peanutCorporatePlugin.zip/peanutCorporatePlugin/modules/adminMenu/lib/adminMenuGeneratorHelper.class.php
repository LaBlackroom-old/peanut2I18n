<?php

/**
 * adminMenu module helper.
 *
 * @package    peanutCorporatePlugin
 * @subpackage adminMenu
 * @author     Alexandre "pocky" Balmes <albalmes@gmail.com>
 * @version    SVN: $Id: helper.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class adminMenuGeneratorHelper extends BaseAdminMenuGeneratorHelper
{
}
