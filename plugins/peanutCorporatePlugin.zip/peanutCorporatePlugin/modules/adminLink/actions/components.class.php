<?php

/**
 * adminLink components.
 *
 * @package    peanutCorporatePlugin
 * @subpackage adminLink
 * @author     Alexandre "pocky" Balmes <albalmes@gmail.com>
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class adminLinkComponents extends sfComponents
{
  public function executeMenu()
  {
  }
}
