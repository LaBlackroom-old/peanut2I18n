<p itemscope itemtype="http://data-vocabulary.org/Person">
  <?php echo __('Published by', null, 'peanutCorporate') ?> <span itemprop="name"><?php echo $author['first_name'] . ' ' . $author['last_name'] ?></span>
</p>